package com.cg.customer.exception;

public class CustomerException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = -4396443553010606645L;

	public CustomerException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
