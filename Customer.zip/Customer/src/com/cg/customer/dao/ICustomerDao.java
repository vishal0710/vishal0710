package com.cg.customer.dao;

import com.cg.customer.bean.Customer;
import com.cg.customer.exception.CustomerException;



public interface ICustomerDao {
	public int addComplaint(Customer customer) throws CustomerException;

	public Customer getComplaint(int complaintid) throws CustomerException;
}
