package com.cg.customer.service;

import com.cg.customer.bean.Customer;
import com.cg.customer.exception.CustomerException;

public interface ICustomerService {
	public int addComplaint(Customer customer) throws CustomerException;
	public Customer getComplaint(int complaintid) throws CustomerException;
}
