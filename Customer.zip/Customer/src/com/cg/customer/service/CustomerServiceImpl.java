package com.cg.customer.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.customer.bean.Customer;
import com.cg.customer.dao.ICustomerDao;
import com.cg.customer.exception.CustomerException;

@Service
public class CustomerServiceImpl implements ICustomerService {

	@Autowired
	ICustomerDao customerDao;
	
	
	@Override
	public int addComplaint(Customer customer) throws CustomerException {
		customer.setStatus("open");
		
		if(customer.getCategory().equals("Internet Banking"))
		{
			customer.setPriority("High");
		}
		else if(customer.getCategory().equals("General Banking"))
		{
			customer.setPriority("Medium");
		}
		else if(customer.getCategory().equals("Others"))
		{
			customer.setPriority("Low");
		}
		return customerDao.addComplaint(customer);
	}


	@Override
	public Customer getComplaint(int complaintid) throws CustomerException {
		return customerDao.getComplaint(complaintid);
	}

}
