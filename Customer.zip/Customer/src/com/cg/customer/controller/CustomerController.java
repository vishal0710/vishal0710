package com.cg.customer.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.customer.bean.Customer;
import com.cg.customer.exception.CustomerException;
import com.cg.customer.service.ICustomerService;

@Controller
public class CustomerController {

	@Autowired
	ICustomerService customerService;
	
	@RequestMapping("showHomePage")
	public String showIndexPage()
	{
		return("index");
	}
	
	
	
	@RequestMapping(value = "addComplaintDetails", method = RequestMethod.POST)
	public ModelAndView addComplaint(@ModelAttribute("complaint") Customer customer,BindingResult result)
	{
		ModelAndView mv = new ModelAndView();
		if (result.hasErrors()) {
			mv.setViewName("error");
			mv.addObject("message", result);
		}
		else 
		{
			try 
			{
				System.out.println(customer.getComplaintid());
				int complaintid = customerService.addComplaint(customer);
				mv.setViewName("addSuccess");
				mv.addObject("complaintid", complaintid);
				
			} catch (CustomerException e) {
				mv.setViewName("error");
				mv.addObject("message", e.getMessage());
				
			}
		}
		return mv;
	}
	
	@RequestMapping("retrieve")
	public String retrieveComplaint()
	{
		return ("retrieveComplaint");
	}

	@RequestMapping(value="showComplaint", method=RequestMethod.POST)
	public ModelAndView retrieve(@RequestParam("complaintid") int complaintid){
		ModelAndView mv= new ModelAndView();
		try{
			Customer customer=customerService.getComplaint(complaintid);
			mv.setViewName("retrieveComplaint");
			mv.addObject("customer", customer);
		}
		catch(CustomerException e)
		{
			mv.setViewName("error");
			mv.addObject("message", e.getMessage());
		}
		return mv;
	}
	
	

}
