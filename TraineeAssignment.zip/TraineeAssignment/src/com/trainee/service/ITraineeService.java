package com.trainee.service;

import java.util.List;

import com.trainee.bean.TraineeBean;
import com.trainee.exception.TraineeException;

public interface ITraineeService {
	
	public int addTrainee(TraineeBean bean) throws TraineeException ;
	
	public TraineeBean search(int traineeId) throws TraineeException;
	
	public List<TraineeBean>viewAllTrainee() throws TraineeException;
	 
	public boolean deleteTrainee(int traineeId) throws TraineeException;
	 
	public boolean updateEmployeeTrainee(TraineeBean traineeBean) throws TraineeException;
}
