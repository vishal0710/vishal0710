package com.ems.exception;

public class EmployeeException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2617583398623591030L;

	public EmployeeException(String message)
	{
		super(message);
	}
}
