package com.ems.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ems.bean.EmployeeBean;
import com.ems.dao.IEmployeeDao;
import com.ems.exception.EmployeeException;

@Service
public class EmployeeServiceImpl implements IEmployeeService {
	@Autowired
	private IEmployeeDao employeeDao;
	@Override
	public int addEmployee(EmployeeBean bean) throws EmployeeException {
		LocalDate date = LocalDate.now();
		bean.setDoj(date);
		return employeeDao.addEmployee(bean);
	}
	@Override
	public List<EmployeeBean> viewAllEmployee() throws EmployeeException {
		return employeeDao.viewAllEmployee();
	}
	@Override
	public boolean deleteEmployee(int employeeId) throws EmployeeException {

		return employeeDao.deleteEmployee(employeeId);
	}
	@Override
	public boolean updateEmployee(EmployeeBean employeeBean)
			throws EmployeeException {
		return employeeDao.updateEmployee(employeeBean);
	}

}
