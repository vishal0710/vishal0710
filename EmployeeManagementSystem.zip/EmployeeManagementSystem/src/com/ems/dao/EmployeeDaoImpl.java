package com.ems.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.ems.bean.EmployeeBean;
import com.ems.exception.EmployeeException;

@Repository
@Transactional
public class EmployeeDaoImpl implements IEmployeeDao {
	
	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public int addEmployee(EmployeeBean bean) throws EmployeeException {
		int id=0;
		try {
			entityManager.persist(bean);
			entityManager.flush();
			id=bean.getEmployeeId();
		} catch (Exception e) {
			throw new EmployeeException("unable to persist in Dao layer "+e.getMessage());
		}
		return id;
	}

	@Override
	public List<EmployeeBean> viewAllEmployee() throws EmployeeException {
		
		List<EmployeeBean> list;
		try {
			TypedQuery<EmployeeBean>query=entityManager.createQuery("select e from EmployeeBean e", EmployeeBean.class);
			list = query.getResultList();
		} catch (Exception e) {
			throw new EmployeeException("unable to fetch records in Dao layer"+ e.getMessage());
		}
		
		return list;
	}

	@Override
	public boolean deleteEmployee(int employeeId)
			throws EmployeeException {
		boolean isdeleted=false;
		
		try {
			EmployeeBean empbean =entityManager.find(EmployeeBean.class,employeeId);
			if(empbean==null)
			{
				System.out.println("Employee Details not found");
				isdeleted= false;
			}
			else
			{
				entityManager.remove(empbean);
				isdeleted=true;
			}
		} catch (Exception e) {
			throw new EmployeeException("unable to delete employee details in Dao Layer"+ e.getMessage());
		}
		return isdeleted;
	}

	@Override
	public boolean updateEmployee(EmployeeBean employeeBean)
			throws EmployeeException {
		
		boolean isUpdated = false;
		
		try {
			
			entityManager.merge(employeeBean);
			isUpdated=true;
		} catch (Exception e) {
			throw new EmployeeException("unable to update employee details in Dao Layer"+ e.getMessage());
		}
		return isUpdated;
	}

}
