package com.ems.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.ems.bean.EmployeeBean;
import com.ems.exception.EmployeeException;
import com.ems.service.IEmployeeService;

@Controller
public class EmployeeController {

	@Autowired
	private IEmployeeService employeeService;
	
	
	
	
	@RequestMapping("viewAll")
	public ModelAndView showAllEmployees()
	{
		ModelAndView model= new ModelAndView();
		try {
			List<EmployeeBean>list=employeeService.viewAllEmployee();
			model.setViewName("viewAll");
			model.addObject("list",list);
		} catch (EmployeeException e) {
			model.setViewName("error");
			model.addObject("message",e.getMessage());
		}
		return model;
	}
	
	
	@RequestMapping("showHomePage")
	public String showHomePage()
	{
		return("index");
	}

	@RequestMapping(value="addEmployee",method=RequestMethod.POST)
	public ModelAndView addEmployee(@ModelAttribute("emp")EmployeeBean bean,BindingResult result)
	{
		ModelAndView model= new ModelAndView();
		if(result.hasErrors())
		{
			model.setViewName("error");
			model.addObject("message", "Binding Failed");
			
		}
		else
		{
				try {
					int id=employeeService.addEmployee(bean);
					model.setViewName("success");
					model.addObject("id",id);
					model.addObject("emp",bean);
				} catch (EmployeeException e) {
					model.setViewName("error");
					model.addObject("message", e.getMessage());
				}
				
				
		}
		return model;
	}
	
	@RequestMapping("deleteEmployee")
	public ModelAndView deleteAllEmployees(@RequestParam("id") int employeeId)
	{
		ModelAndView model= new ModelAndView();
		try {
			boolean isDeleted=false;
			isDeleted=employeeService.deleteEmployee(employeeId);
			
			List<EmployeeBean>list=employeeService.viewAllEmployee();
			
			model.setViewName("viewAll");
			model.addObject("list",list);
		} catch (EmployeeException e) {
			model.setViewName("error");
			model.addObject("message",e.getMessage());
		}
		return model;
	}
	
	@RequestMapping("updateEmployee")
	public ModelAndView updateAllEmployees(@ModelAttribute("emp")EmployeeBean employeeBean,BindingResult result)
	{
		ModelAndView model= new ModelAndView();
		model.setViewName("updateform");
		model.addObject("emp",employeeBean);
		return model;
	}
	
	@RequestMapping(value="update",method=RequestMethod.POST)
	public ModelAndView updateEmployees(@ModelAttribute("emp")EmployeeBean employeeBean,BindingResult result)
	{
		boolean isUpdated=false;
		ModelAndView model= new ModelAndView();
		
		try {
				
				isUpdated=employeeService.updateEmployee(employeeBean);
				
				List<EmployeeBean>list=employeeService.viewAllEmployee();
				model.setViewName("viewAll");
				model.addObject("list",list);
		} catch (EmployeeException e) {
			model.setViewName("error");
			model.addObject("message",e.getMessage());	
		}
		return model;
	}
}