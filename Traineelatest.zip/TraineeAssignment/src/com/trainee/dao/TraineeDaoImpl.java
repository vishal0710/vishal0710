package com.trainee.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.trainee.bean.TraineeBean;
import com.trainee.exception.TraineeException;

@Repository
@Transactional
public class TraineeDaoImpl implements ITraineeDao {

	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public int addTrainee(TraineeBean bean) throws TraineeException {
		int id=0;
		
		
		try {
			entityManager.persist(bean);
			entityManager.flush();
			id=bean.getTraineeId();
		} catch (Exception e) {
			throw new TraineeException("unable to persist in Dao Layer" +e.getMessage());
		}
		
		return id;
	}

	@Override
	public TraineeBean search(int traineeId) throws TraineeException {
		TraineeBean bean;
		try {
			
			bean=entityManager.find(TraineeBean.class, traineeId);
			
		} catch (Exception e) {
			throw new TraineeException("unable to Search records in Dao layer"+ e.getMessage());
		}
		return bean;
	}

	@Override
	public List<TraineeBean> viewAllTrainee() throws TraineeException {
		
		List<TraineeBean> list;
		try {
		TypedQuery<TraineeBean>query=entityManager.createQuery("from TraineeBean", TraineeBean.class);
		list = query.getResultList();
		} catch (Exception e) {
		throw new TraineeException("unable to view all records in Dao layer"+ e.getMessage());
		}
		 
		return list;
		
	}

	@Override
	public boolean deleteTrainee(int traineeId) throws TraineeException {
	
		boolean isdeleted=false;
		 
		try {
		TraineeBean bean =entityManager.find(TraineeBean.class,traineeId);
		if(bean==null)
		{
		System.out.println("trainee Details not found");
		isdeleted= false;
		}
		else
		{
		entityManager.remove(bean);
		isdeleted=true;
		}
		} catch (Exception e) {
		throw new TraineeException("unable to delete trainee details in Dao Layer"+ e.getMessage());
		}
		return isdeleted;

	}

	@Override
	public boolean updateTrainee(TraineeBean traineeBean)
			throws TraineeException {

		boolean isUpdated = false;
		 
		try {
		 
		entityManager.merge(traineeBean);
		isUpdated=true;
		} catch (Exception e) {
		throw new TraineeException("unable to update trainee details in Dao Layer"+ e.getMessage());
		}
		return isUpdated;

	}

	

	

}
