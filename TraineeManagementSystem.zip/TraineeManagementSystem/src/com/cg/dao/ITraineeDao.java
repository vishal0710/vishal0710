package com.cg.dao;

import com.cg.bean.TraineeBean;

public interface ITraineeDao {

	boolean adddetails(TraineeBean traineeBean);

}
