package com.cg.dao;

import com.cg.bean.TraineeBean;

public interface ITrainee {

	public void addTrainee(TraineeBean traineeBean);
	
}
