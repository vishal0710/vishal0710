package com.cg.dao;

import java.util.HashMap;

import org.springframework.stereotype.Repository;

import com.cg.bean.TraineeBean;

@Repository
public class TraineeDao implements ITraineeDao {

	HashMap<Integer,TraineeBean> maps = new HashMap<Integer,TraineeBean>();

	public HashMap<Integer, TraineeBean> getMaps() {
		return maps;
	}

	public void setMaps(HashMap<Integer, TraineeBean> maps) {
		this.maps = maps;
	}

	@Override
	public boolean adddetails(TraineeBean traineeBean) {
		maps.put(traineeBean.getTraineeId(), traineeBean);
		 System.out.println(maps.get(traineeBean.getTraineeId()-1));
		return maps.containsKey(traineeBean.getTraineeId());
		
	}
	
	
	
}
