package com.cg.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.bean.TraineeBean;

public class TraineeDaoImpl implements ITrainee {

	Map<Integer,TraineeBean>map=new HashMap<Integer,TraineeBean>();
	
	
	@Override
	public void addTrainee(TraineeBean traineeBean) {
		
		map.put(traineeBean.getTraineeId(),traineeBean);
	}

}
