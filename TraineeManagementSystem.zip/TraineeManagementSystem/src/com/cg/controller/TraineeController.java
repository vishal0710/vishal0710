package com.cg.controller;

import org.springframework.stereotype.Controller;

import com.cg.service.IService;

@Controller
public class TraineeController {

	private IService traineeService;

	public IService getTraineeService() {
		return traineeService;
	}

	public void setTraineeService(IService traineeService) {
		this.traineeService = traineeService;
	}
	
	
	
}
