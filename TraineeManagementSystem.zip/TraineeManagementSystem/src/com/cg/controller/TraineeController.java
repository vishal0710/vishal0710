package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.bean.TraineeBean;
import com.cg.service.ITraineeService;

@Controller
public class TraineeController {
	
	@Autowired
	ITraineeService traineeService;



	public ITraineeService getTraineeService() {
		return traineeService;
	}

	public void setTraineeService(ITraineeService traineeService) {
		this.traineeService = traineeService;
	}

	@RequestMapping("show")
	public String startPage(){
		
		return "index";
	}
	
	@RequestMapping("register")
	public String insertEmp(){
		
		return "register";
	}
	
	@RequestMapping(value="adddetails",method=RequestMethod.POST)
	public String addDetails(@ModelAttribute("trainee") TraineeBean bean,BindingResult result,Model model){
		
		String target="";
		if(result.hasErrors()){
			model.addAttribute("message",result);
			target = "error";
		}else{
			boolean isInserted = traineeService.adddetails(bean);
			if(isInserted){
				model.addAttribute("message","Successfully Inserted");
			}else{
				model.addAttribute("message","Insertion Failed");
			}
			target = "success";
		}
		return target;
	}
}
