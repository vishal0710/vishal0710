package com.cg.service;

import com.cg.bean.TraineeBean;

public interface IService {

	public void addTrainee(TraineeBean traineeBean);
}
