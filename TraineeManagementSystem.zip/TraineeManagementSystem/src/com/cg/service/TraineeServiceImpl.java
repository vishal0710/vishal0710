package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.TraineeBean;
import com.cg.dao.ITrainee;

@Service
public class TraineeServiceImpl implements IService{

	@Autowired
	ITrainee traineeDao;
	
	
	
	public ITrainee getTraineeDao() {
		return traineeDao;
	}



	public void setTraineeDao(ITrainee traineeDao) {
		this.traineeDao = traineeDao;
	}



	@Override
	public void addTrainee(TraineeBean traineeBean) {
			
		traineeDao.addTrainee(traineeBean);
		
	}

}
