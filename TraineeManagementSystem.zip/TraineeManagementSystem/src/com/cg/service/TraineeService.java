package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.TraineeBean;
import com.cg.dao.ITraineeDao;

@Service
public class TraineeService implements ITraineeService {

	@Autowired
	ITraineeDao traineeDao;

	public ITraineeDao getTraineeDao() {
		return traineeDao;
	}

	public void setTraineeDao(ITraineeDao traineeDao) {
		this.traineeDao = traineeDao;
	}

	@Override
	public boolean adddetails(TraineeBean traineeBean) {
		
		return traineeDao.adddetails(traineeBean);
	}
	
	
}
