package com.cg.service;

import com.cg.bean.TraineeBean;

public interface ITraineeService {

	boolean adddetails(TraineeBean traineeBean);
}
