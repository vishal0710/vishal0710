package com.product.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.product.bean.Product;
import com.product.dao.IProductDao;
import com.product.exception.ProductException;

@Service
public class ProductServiceImpl implements IProductService {
	
	@Autowired
	private IProductDao productDao;
	
	
	@Override
	public List<Product> viewAll() throws ProductException {
		
		return productDao.viewAll();
	}


	@Override
	public boolean delete(int product_id) throws ProductException {
		
		return productDao.delete(product_id);
	}

}
