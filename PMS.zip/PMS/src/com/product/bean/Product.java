package com.product.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Product")
public class Product {
	@Id
	@Column(name="product_id")
	private int product_id;
	@Column(name="product_name")
	private String productName;
	@Column(name="product_price")
	private double price;
	@Column(name="product_quantity")
	private int quantity;
	@Column(name="description")
	private String desc;
	public Product() {
		super();
	}
	public Product(int product_id, String productName, double price,
			int quantity, String desc) {
		super();
		this.product_id = product_id;
		this.productName = productName;
		this.price = price;
		this.quantity = quantity;
		this.desc = desc;
	}
	public int getProduct_id() {
		return product_id;
	}
	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	@Override
	public String toString() {
		return "Product [product_id=" + product_id + ", productName="
				+ productName + ", price=" + price + ", quantity=" + quantity
				+ ", desc=" + desc + "]";
	}
	

}
